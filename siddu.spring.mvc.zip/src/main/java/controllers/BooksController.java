package controllers;

import java.sql.SQLException;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import dao.BookRepository;
import entities.Book;

@Controller
@Transactional
public class BooksController {
	
	@Autowired
	private BookRepository bookRepo;
	@Autowired
	private DataSource dataSource;
	
	
	@RequestMapping(method={RequestMethod.GET},value="/show")
	public String openStore(Map model){
		model.put("books", bookRepo.getBooks());
		return "Books";
	}
	
	@RequestMapping(method={RequestMethod.GET},value="/add")
	public String showAddBook(){
		return "AddBook";
	}
	
	@RequestMapping(method={RequestMethod.POST},value="/addBook")
	public String addBook(Book book, Map model) throws SQLException{
		bookRepo.addBook(book);
		model.put("status", "Book Added successfully");
		model.put("connection",dataSource.getConnection().toString() );
		return "AddBook";
	}
	
	@RequestMapping(method={RequestMethod.GET},value="/bookHome")
	public String showApp(){
		return "BooksApp";
	}
	
	
}
