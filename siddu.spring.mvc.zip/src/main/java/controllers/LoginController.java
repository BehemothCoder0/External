package controllers;

import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import dao.UserRepository;
import entities.User;

@Controller
public class LoginController {
	
	@Autowired
	private UserRepository userRepo;
	
	@RequestMapping(method={RequestMethod.POST},value="/login")
	public String login(@Valid User user, Errors errors, Map model){
		/*if(errors.hasErrors()){
			model.put("loginError","Enter credentials");
			return "Login";
		}
		
		else if(userRepo.isUserExists(user)){
			return "BooksApp";
		}
		else{
			model.put("loginError","Invalid Credentials");
			return "Login";
		}*/
		
		if(user.getUsername().equals("siddartha") && user.getPassword().equals("siddu")){
			return "BooksApp";
		}
		else{
			model.put("loginError","Invalid Credentials");
			return "Login";
		}
	}
	
	@RequestMapping(method={RequestMethod.GET},value="/register")
	public String register(){
		return "Register";
	}
	
	@RequestMapping(method={RequestMethod.GET},value="/")
	public String showLoginPage(){
		return "Login";
	}
	
	public String showProfilePage(){
		return "Profile";
	}
	
	@RequestMapping(method={RequestMethod.POST},value="/registerUser")
	public String registerUser(@Valid User user, Errors errors, Map model){
		if(errors.hasErrors()){
			model.put("registerError", "Enter all mandatory fields");
			return "Register";
		}
		else if(userRepo.isUserExists(user)){
			model.put("registerError", "User Already exists");
			return "Register";
		}
		else{
			userRepo.addUser(user);
			model.put("registerSuccess", "User Added Successfully");
			return "Register";
		}
	}
}
