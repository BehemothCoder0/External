package entities;

import org.springframework.stereotype.Component;


public class Dummy {
	public void test(){
		System.out.println("Just testing");
	}
}
