package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaQuery;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import entities.Book;

@Repository
public class BookRepository {
	
	@PersistenceContext(unitName="BookPersistence")
	private EntityManager entityManager;
	
	
	public void addBook(Book book){
		System.out.println(entityManager.toString());
		entityManager.persist(book);
		
		
	}
	
	public List<Book> getBooks(){
		CriteriaQuery<Book> criteria = entityManager.getCriteriaBuilder().createQuery(Book.class);
	    criteria.select(criteria.from(Book.class));
	    List<Book> books = entityManager.createQuery(criteria).getResultList();
	    return books;
	}
}
