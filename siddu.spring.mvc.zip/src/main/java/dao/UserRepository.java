package dao;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;

import entities.User;

@Repository
public class UserRepository {
	private List<User> users;
	
	public UserRepository() {
		users = new ArrayList<User>();
	}
	
	public void addUser(User user){
		users.add(user);
	}
	
	public boolean isUserExists(User user){
		boolean isExists = false;
		for(User curUser:users){
			if(curUser.equals(user)){
				isExists = true;
			}
			
		}
		return isExists;	
		
	}
}
